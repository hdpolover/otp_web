###################
What is OTP WEB
###################

This is a simple website using codeigniter 3.x, that handles regristration and login process with activation process and OTP SMS.

DB NAME: sms_otp